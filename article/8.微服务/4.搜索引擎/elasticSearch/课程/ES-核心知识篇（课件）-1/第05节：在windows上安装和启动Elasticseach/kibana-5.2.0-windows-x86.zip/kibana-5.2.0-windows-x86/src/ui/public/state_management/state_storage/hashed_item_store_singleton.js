import HashedItemStore from './hashed_item_store';

export default new HashedItemStore(window.sessionStorage);
