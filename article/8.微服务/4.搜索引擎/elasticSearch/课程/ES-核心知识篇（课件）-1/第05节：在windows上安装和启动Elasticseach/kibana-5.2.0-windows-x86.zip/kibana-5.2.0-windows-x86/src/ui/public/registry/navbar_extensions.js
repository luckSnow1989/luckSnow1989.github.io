import uiRegistry from 'ui/registry/_registry';
export default uiRegistry({
  name: 'navbarExtensions',
  index: ['name'],
  group: ['appName'],
  order: ['order']
});
