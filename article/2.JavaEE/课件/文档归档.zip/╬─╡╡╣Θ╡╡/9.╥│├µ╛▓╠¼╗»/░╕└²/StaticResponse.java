package com.zx.servlet;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class StaticResponse extends HttpServletResponseWrapper {

	private PrintWriter pw;
	
	//[使用路径创建流！当使用该流写数据时，数据会写入到指定路径的文件中。]
	public StaticResponse(HttpServletResponse response, String filepath)
			throws FileNotFoundException, UnsupportedEncodingException {
		super(response);
		System.out.println(filepath);
		pw = new PrintWriter(filepath, "UTF-8");
	}

	//[jsp页面会调用本方法获取这个流！使用它来写入页面中的数据。这些数据都写入到指定路径的页面中去了，即写入到静态页面中。]
	public PrintWriter getWriter () throws IOException {
		return pw;
	}

	//[刷新流，使缓冲区中的数据也写入到目标！]
	public void close() throws IOException {
		pw.close();
	}


}
