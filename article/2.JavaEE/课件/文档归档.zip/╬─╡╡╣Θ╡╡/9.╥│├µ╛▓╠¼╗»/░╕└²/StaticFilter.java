package com.zx.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebFilter(urlPatterns="*.html")
public class StaticFilter implements Filter {
	
	private ServletContext sc;
	
	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;

//		[获取分类参数，分类参数可能是：1,2,3,null。使用分类参数做key]
		String key = "key_"  + req.getServletPath().replace("/", "");
//		[在ServletContext中获取Map，首次访问这个Map不存在。]
		Map<String,String> map = (Map<String, String>) sc.getAttribute("pages");
//		[如果Map不存在，那么创建一个Map，并存放到ServletContext中，这样下次访问Map就存在了。]
		if(map == null) {
			map = new HashMap<String,String>();
			sc.setAttribute("pages", map);
		}
		
//		[查看Map中是否存在这个key，如果存在，那么获取值，值就是这个参数对应的静态页面路径。然后直接重定向到静态页面！]
		if(map.containsKey(key)) {
			res.sendRedirect(req.getContextPath() + "/" + map.get(key));
			return;
		}

//		[如果当前请求参数对应的静态页面不存在，那么就生成静态页面，首先静态页面的名称为key，容颜名为html]
		String html = key + ".html";
//		[生成真实路径，下面会使用这个路径创建静态页面。]
		String realPath = sc.getRealPath("/" + html);
//		[创建自定义的response对象，传递待生成的静态页面路径]
		StaticResponse sr = new StaticResponse(res, realPath);
		chain.doFilter(request, sr);
//		[这个方法的作用是刷新缓冲区！]
		sr.close();

//		[这时静态页面已经生成，重定向到静态页面]
		res.sendRedirect(req.getContextPath() + "/" + html);
//		[把静态页面保存到map中，下次访问时，直接从map中获取静态页面，不用再次生成。]
		map.put(key, html);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		this.sc = fConfig.getServletContext();
	}
}
