package com.zx.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

/**
 * @Project: 20200218-response-code
 * @Title: IpUtils
 * @Description: ip工具类
 * @author: zhangxue
 * @date: 2020年2月19日下午1:58:54
 * @company: 未知
 * @Copyright: Copyright (c) 2015
 * @version v1.0
 */
public class IpUtils {

    private static final Pattern IPV4_PATTERN = Pattern.compile("^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$");
    private static final Pattern IPV6_PATTERN = Pattern.compile("^([\\da-fA-F]{1,4}:){7}[\\da-fA-F]{1,4}$");

    /**
     * @Title: 判断ip是否是ipV4协议
     * @param addr
     * @return
     * @date: 2020年2月19日下午1:46:08
     * @author: zhangxue
     */
    public static boolean isIPV4(String addr) {
        return isMatch(addr, IPV4_PATTERN);
    }

    /**
     * @Title: 判断ip是否是ipV6协议
     * @param addr
     * @return
     * @date: 2020年2月19日下午1:46:08
     * @author: zhangxue
     */
    public static boolean isIPV6(String addr) {
        return isMatch(addr, IPV6_PATTERN);
    }

    private static boolean isMatch(String data, Pattern pattern) {
        if (data == null || data.trim().length() == 0) {
            return false;
        }
        Matcher mat = pattern.matcher(data);
        return mat.find();
    }
    
    /**
     * @Title: ipv4 进行ip的格式转换
     * @param longIp
     * @return
     * @date: 2020年2月19日下午1:47:15
     * @author: zhangxue
     */
    public static String longToIpV4(long longIp) {
        int octet3 = (int) ((longIp >> 24) % 256);
        int octet2 = (int) ((longIp >> 16) % 256);
        int octet1 = (int) ((longIp >> 8) % 256);
        int octet0 = (int) ((longIp) % 256);
        return octet3 + "." + octet2 + "." + octet1 + "." + octet0;
    }

    /**
     * @Title: ipv4 进行ip的格式转换
     * @param longIp
     * @return
     * @date: 2020年2月19日下午1:47:15
     * @author: zhangxue
     */
    public static long ipV4ToLong(String ip) {
        String[] octets = ip.split("\\.");
        return (Long.parseLong(octets[0]) << 24) + (Integer.parseInt(octets[1]) << 16)
                + (Integer.parseInt(octets[2]) << 8) + Integer.parseInt(octets[3]);
    }

    /**
     * @Title: 判断ipV4是否是内网/局域网
     * @param ip
     * @return
     * @date: 2020年2月19日下午1:47:46
     * @author: zhangxue
     */
    public static boolean isIPv4Private(String ip) {
        long longIp = ipV4ToLong(ip);
        return (longIp >= ipV4ToLong("10.0.0.0") && longIp <= ipV4ToLong("10.255.255.255"))
                || (longIp >= ipV4ToLong("172.16.0.0") && longIp <= ipV4ToLong("172.31.255.255"))
                || longIp >= ipV4ToLong("192.168.0.0") && longIp <= ipV4ToLong("192.168.255.255");
    }
    
    /**
     * 获取客户端IP
     */
    public static String getIp(HttpServletRequest request) {
    	/*
    	Nginx 作为反向代理，容器获得ip的时候通过 request.getRemoteAddr() 获得的是Nginx的ip（如果容器与Nginx在同一个内网区域内，则获得的是Nginx的内网ip）
    	想要获得真实的ip，我们会在Nginx进行配置， 将Nginx获得的真实ip，写到header中，key是 X-Forward-For
    	  	
    	location  ~  ^/static {
    		proxy_pass  ....;
    		proxy_set_header X-Forward-For $remote_addr ;// 这个值可能存在多个ip，所以使用逗号隔开（这个场景是请求是通过代理的方式发出的），我们一般认为多个ip中的第一个ip就是客户的真实ip（除非使用高匿代理）
    	}
    	*/
        String check = "unKnown";
        String ip = request.getHeader("X-Forward-For");
        if (ip != null && !"".equals(ip) && !check.equalsIgnoreCase(ip)) {
            // 多次反向代理后会有多个ip值，第一个ip才是真实ip
            int index = ip.indexOf(",");
            if (index != -1) {
            	ip = ip.substring(0, index);
            	if( isIPV4(ip) && !isIPv4Private(ip) ) {
            		return ip;
            	}
            } else {
                return ip;
            }
        }
        ip = request.getHeader("X-Real-IP");
        if (ip != null && !"".equals(ip) && !check.equalsIgnoreCase(ip)) {
            return ip;
        }
        return request.getRemoteAddr();
    }

}
