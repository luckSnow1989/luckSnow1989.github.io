
package com.webyun.xywl.web.filter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.webyun.xywl.web.filter.wrapper.GZIPResponseWrapper;

/**
 * @Project: xywl
 * @Title: GZIPFilter
 * @Description: 全局Gzip压缩过滤器
 * @author: zhangx
 * @date: 2017年3月22日 上午8:58:16
 * @company: webyun
 * @Copyright: Copyright (c) 2017
 * @version v1.0
 */
@WebFilter(filterName = "b_gzipFilter", urlPatterns = "/*")
public class GZIPFilter implements Filter {
	
	private static final Logger logger = LoggerFactory.getLogger(GZIPFilter.class);

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) {
		
		HttpServletRequest request = (HttpServletRequest) req;
		
		String acceptEncoding = request.getHeader("Accept-Encoding");
		// 判断浏览器是否支持gzip格式
		if ((acceptEncoding != null) && (acceptEncoding.indexOf("gzip") != -1)) {
			logger.info("开始gzip压缩");
			HttpServletResponse response = (HttpServletResponse) res;
			//对输出的内容进行Gzip压缩
			GZIPResponseWrapper wrapper = new GZIPResponseWrapper(response);
			
			try {
				chain.doFilter(request, wrapper);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ServletException e) {
				e.printStackTrace();
			}
			
			try {
				wrapper.finish();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			ByteArrayOutputStream buffer = wrapper.getBuffer();
			
			response.addHeader("Content-Encoding", "gzip");
			
			response.setContentLength(buffer.size());
			
			ServletOutputStream output = null;
			try {
				output = response.getOutputStream();
				output.write(buffer.toByteArray());
				output.flush();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} else {
			try {
				chain.doFilter(req, res);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ServletException e) {
				e.printStackTrace();
			}
		}
	}

	public void init(FilterConfig config) throws ServletException {	}
	
	public void destroy() { }
}
