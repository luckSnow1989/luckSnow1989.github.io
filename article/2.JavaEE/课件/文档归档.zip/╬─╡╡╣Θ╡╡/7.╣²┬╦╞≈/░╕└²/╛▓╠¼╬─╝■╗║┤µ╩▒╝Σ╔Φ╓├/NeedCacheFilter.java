package 过滤器.案例;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
  * 设置静态文件缓存时间过滤器
  * @Project: 20160615_i18n
  * @Title: NeedCacheFilter
  * @Description: TODO
  * @author: zhangxue
  * @date: 2016年6月19日下午7:29:24
  * @version v1.0
  */
//@WebFilter(filterName="NeedCacheFilter",
//		urlPatterns = {"*.html","*.css","*.js"}, initParams = {
//		@WebInitParam(name = "html", value = "1"),// value是缓存的时间
//		@WebInitParam(name = "css", value = "1") })
public class NeedCacheFilter implements Filter {

	private FilterConfig filterConfig;

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		// 获取html、css、js各自的缓存时间，如果没有，给个默认值是1小时
		String value = null;
		String uri = request.getRequestURI();// /day19/index.html
		String extendName = uri.substring(uri.lastIndexOf(".") + 1);

		if ("html".equals(extendName)) {// 访问的html资源
			value = filterConfig.getInitParameter("html");
		} else if ("css".equals(extendName)) {// 访问的css资源
			value = filterConfig.getInitParameter("css");
		} else if ("js".equals(extendName)) {// 访问的js资源
			value = filterConfig.getInitParameter("js");
		}
		if (value != null) {
			int time = Integer.parseInt(value);
			response.setDateHeader("Expires", System.currentTimeMillis() + time * 60 * 60 * 1000);
		}
		chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		this.filterConfig = config;
	}

}
