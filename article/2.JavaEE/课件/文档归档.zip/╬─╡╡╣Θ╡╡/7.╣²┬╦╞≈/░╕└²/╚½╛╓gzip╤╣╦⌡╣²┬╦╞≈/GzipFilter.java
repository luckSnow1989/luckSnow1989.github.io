package 过滤器.案例;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.zip.GZIPOutputStream;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
/**
  * @Project: 20160615_i18n
  * @Title: GzipFilter
  * @Description: 全站压缩过滤器,只能压缩response的值，request中的属性，暂时不能,默认是要压缩的，不需要压缩的时候
  * 	需要指定IS_DISPATCHER=no获得false
  * @author: zhangxue
  * @date: 2016年6月19日下午7:30:32
  * @version v1.0
  */
//@WebFilter(urlPatterns="/*")
public class GzipFilter implements Filter {

	public void destroy() {

	}

	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)resp;

		String is = request.getParameter("IS_DISPATCHER");
		
		//判断是否是转发
		if(is != null) {
			chain.doFilter(request, response);//放行
			response.setHeader("Content-Encoding", "gzip");
		} else if(is == null){
			GzipHttpServletResponse gresponse = new GzipHttpServletResponse(response);
			System.out.println("*****************************");
			System.out.println("请求的目标：" + request.getRequestURL());
			chain.doFilter(request, gresponse);//放行
		
			//1.压缩代码写在此处
			//找一个内存缓冲字节流
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			//2.把数据压缩到缓冲字节流流中
			GZIPOutputStream gout = new GZIPOutputStream(baos);
			//3.取出数据：压缩前的
			byte b[] = gresponse.getOldBytes();//原始字节
			System.out.println("原有数据大小："+b.length);
			gout.write(b);
			//4.开始压缩
			gout.close();
			//5.取出压缩后的数据
			b = baos.toByteArray();
			System.out.println("压缩后的数据大小："+b.length);
			
			//6.输出前一定要告知客户端压缩方式
			response.setHeader("Content-Encoding", "gzip");
			response.setContentLength(b.length);//告知客户端正文的大小
			
			//7.用服务器的响应对象输出
			OutputStream out = response.getOutputStream();
			out.write(b);
		}
	}

	public void init(FilterConfig filterConfig) throws ServletException {

	}
	
	/**
	  * @Project: 20160615_i18n
	  * @Title: GzipHttpServletResponse
	  * @Description: 用于增强Response的能力，增加内存缓冲字节流的功能。
	  * @author: zhangxue
	  * @date: 2016年6月19日下午7:32:25
	  * @version v1.0
	 */
	private class GzipHttpServletResponse extends HttpServletResponseWrapper{
		//内存缓冲字节流，作用是将在servlet中响应的结果全部封装到字节流中，便于之后数据的获取
		private ByteArrayOutputStream baos = new ByteArrayOutputStream();
		
		private PrintWriter pw;
		
		public GzipHttpServletResponse(HttpServletResponse response){
			super(response);
		}
		
		//把原始数据封装到一个缓冲流中
		@Override
		public ServletOutputStream getOutputStream() throws IOException {
			return new SupperServletOutputStream(this.baos);
		}
		
		//字符流：把原始数据封装到一个缓冲流中
		@Override
		public PrintWriter getWriter() throws IOException {
			//字符流转成字节流编码会丢失
			pw = new PrintWriter(new OutputStreamWriter(baos, super.getCharacterEncoding()));
			return pw;
		}
		
		//返回baos中的缓存数据：原始
		public byte[] getOldBytes(){
			try {
				if(pw!=null){
					pw.close();
				}
				baos.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return baos.toByteArray();
		}
		
	}
	
	private class SupperServletOutputStream extends ServletOutputStream{
		
		private ByteArrayOutputStream baos;
		
		public SupperServletOutputStream(ByteArrayOutputStream baos){
			this.baos = baos;
		}
		
		@Override
		public void write(int b) throws IOException {
			baos.write(b);
		}
	}
}
