package 过滤器.案例;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
/**
  * @Project: 20160615_i18n
  * @Title: HtmlFilter
  * @Description: HTML特殊符号过滤器。
  * 	例如	<   替换为	&lt;
  * @author: zhangxue
  * @date: 2016年6月19日下午7:46:49
  * @version v1.0
  */
public class HtmlFilter implements Filter {

	public void destroy() {

	}

	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)resp;
		HtmlHttpServletRequest hrequest = new HtmlHttpServletRequest(request);
		chain.doFilter(hrequest, response);
	}

	public void init(FilterConfig filterConfig) throws ServletException {

	}

	private class HtmlHttpServletRequest extends HttpServletRequestWrapper{
		public HtmlHttpServletRequest(HttpServletRequest request){
			super(request);
		}
		
		@Override
		public String getParameter(String name) {
			String value = super.getParameter(name);
			if(value==null)
				return value;
			value = htmlFilter(value);//完成标记过滤
			return value;
		}
		
		private String htmlFilter(String message) {
			if (message == null)
				return (null);
			
			char content[] = new char[message.length()];
			message.getChars(0, message.length(), content, 0);
			StringBuffer result = new StringBuffer(content.length + 50);
			for (int i = 0; i < content.length; i++) {
				switch (content[i]) {
				case '<':
					result.append("&lt;");
					break;
				case '>':
					result.append("&gt;");
					break;
				case '&':
					result.append("&amp;");
					break;
				case '"':
					result.append("&quot;");
					break;
				default:
					result.append(content[i]);
				}
			}
			return (result.toString());
		}
	}
}
