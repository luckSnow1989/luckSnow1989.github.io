
package com.webyun.xywl.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import com.webyun.xywl.web.filter.wrapper.XssHttpServletRequestWrapper;
/**
 * 
 * @Project: xywl
 * @Title: XssFilter
 * @Description: 拦截请求防止XSS漏洞与SQL注入漏洞
 * @author: zhangx
 * @date: 2017年3月22日 上午11:23:52
 * @company: webyun
 * @Copyright: Copyright (c) 2017
 * @version v1.0
 */
@WebFilter(filterName = "a_xssFilter", urlPatterns = "*.do")
public class XssFilter implements Filter {
	
	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		chain.doFilter(new XssHttpServletRequestWrapper((HttpServletRequest) request), response);
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
	}
}