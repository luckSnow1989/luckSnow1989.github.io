package 过滤器.案例;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

/**
 * @Project: 20160615_i18n
 * @Title: DirtyWordsFilter
 * @Description: (敏感词)脏话过滤器
 * @author: zhangxue
 * @date: 2016年6月18日下午10:45:28
 * @version v1.0
 */
//@WebFilter(urlPatterns = "/*")
public class DirtyWordsFilter implements Filter {

	public void destroy() {

	}

	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		//包装增强getParameter方法，对敏感词过滤
		DirtyWordsHttpServletRequest drequest = new DirtyWordsHttpServletRequest(request);
		chain.doFilter(drequest, response);
	}

	public void init(FilterConfig filterConfig) throws ServletException {

	}
	
	private class DirtyWordsHttpServletRequest extends HttpServletRequestWrapper {
		private String words[] = { "傻B", "畜生", "禽兽" };

		public DirtyWordsHttpServletRequest(HttpServletRequest request) {
			super(request);
		}

		@Override
		public String getParameter(String name) {
			String value = super.getParameter(name);
			System.out.println("敏感词过滤" +value);
			if (value == null)
				return null;
			for (String dword : words) {
				if (value.contains(dword)) {// 判断用户输入的内容中包含脏话
					value = value.replace(dword, "**");
				}
			}
			return value;
		}

	}
}

