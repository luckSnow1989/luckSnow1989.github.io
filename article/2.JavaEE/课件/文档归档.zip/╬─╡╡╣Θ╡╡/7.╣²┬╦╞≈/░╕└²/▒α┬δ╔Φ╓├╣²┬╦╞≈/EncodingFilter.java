package 过滤器.案例;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
/**
  * 
  * @Project: 20160615_i18n
  * @Title: EncodingFilter
  * @Description: 统一编码过滤器
  * @author: zhangxue
  * @date: 2016年6月19日下午7:28:31
  * @version v1.0
  */
//@WebFilter(urlPatterns = "/*", 
//	initParams = { @WebInitParam(name = "encoding", value = "UTF-8") }// 2.配置初始化参数
//)
public class EncodingFilter implements Filter {

	private String encoding;

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		
		//System.out.println("现在的编码是：" + this.encoding);

		// 1.设置POST请求方式的中文请求参数的编码
		// 1.1 设置POST请求方式的中文请求参数的编码
		request.setCharacterEncoding(this.encoding);
		// 1.2 设置响应输出时的编码：字符流和字节流
		response.setCharacterEncoding(this.encoding);
		// 1.3 字节流输出时通知客户端的解码码表
		response.setContentType("test/html;charset=" + this.encoding);
		
		//2.包装get方法的getParameter的编码
		request = new getMethodRequestHeadler(request);
		
		chain.doFilter(request, response);// 放行
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		String encoding = config.getInitParameter("encoding");
		if (encoding == null || encoding.length() == 0) {
			this.encoding = "GBK";
		} else {
			this.encoding = encoding;
		}
	}

	// HttpServletRequestWrapper内部的代码与连接池原理中那个默认适配器一样
	private class getMethodRequestHeadler extends HttpServletRequestWrapper {
		
		public getMethodRequestHeadler(HttpServletRequest request) {
			super(request);
		}

		/**
		 * 只对get请求方式进行改写
		 */
		@Override
		public String getParameter(String name) {
			String value = super.getParameter(name);
			if (value == null)
				return value;
			// 得到请求方式,浏览器发送get请求的时候，默认使用ISO-8859-1编码
			String method = super.getMethod();
			if ("GET".equalsIgnoreCase(method)) {
				try {
					value = new String(value.getBytes("ISO-8859-1"), 
							super.getCharacterEncoding());
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
			return value;
		}
		
		/**
		 * 只对get请求方式进行改写
		 */
		@Override
		public String[] getParameterValues(String name) {
			String[] value = super.getParameterValues(name);
			if (value == null)
				return value;
			// 得到请求方式,浏览器发送get请求的时候，默认使用ISO-8859-1编码
			String method = super.getMethod();
			if ("GET".equalsIgnoreCase(method)) {
				try {
					for (String s : value) {
						s = new String(s.getBytes("ISO-8859-1"),  super.getCharacterEncoding());
					}
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
			return value;
		}
	}
}
