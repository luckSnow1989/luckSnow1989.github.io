package verification;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

public class VerificationUtil {
	
	private Graphics g = null;
	private BufferedImage image = null;
	private Random random = new Random();
	private int fontSize;
	private int imgWidth;
	private int imgHeight;
	private String fontType = ConfigDateBase.FONT_TYPES[1];
	/**
	 * 创建的时候，设置大小
	 * @param imgWidth
	 * @param imgHeight
	 */
	public VerificationUtil(int imgWidth, int imgHeight) {
		this.imgWidth = imgWidth;
		this.imgHeight = imgHeight;
		this.image = new BufferedImage(imgWidth, imgHeight, BufferedImage.TYPE_INT_RGB);
		this.g = image.getGraphics();
		// 设定背景色
		this.g.setColor(Color.white);
		// 设置背景色填充的大小
		this.g.fillRect(0, 0, imgWidth, imgHeight);
		// 画边框
		this.g.setColor(Color.GRAY);
		this.g.drawRect(0, 0, imgWidth - 1, imgHeight - 1);
		// 随机产生20条干扰线，使图象中的认证码不易被其它程序探测到
		for (int i = 0; i < 20; i++) {
			this.g.setColor(getRandColor());
			int x = random.nextInt(imgWidth);
			int y = random.nextInt(imgHeight);
			int xl = random.nextInt(imgWidth);
			int yl = random.nextInt(imgHeight);
			this.g.drawLine(x, y, x + xl, y + yl);
		}
	}
	/**
	 * 设置字体样式
	 * @param fontName
	 */
	public void setFontType(String fontName) {
		this.fontType = fontName;
	}
	/**
	 * 生成验证码
	 * @param dateBase
	 * @param length
	 * @return	生成好的验证码
	 */
	public String code(char[] dateBase,int length) {
		// 自动配置字体大小
		this.fontSize = (this.imgWidth/length);
		// 设置默认的字体
		this.g.setFont(new Font(this.fontType, Font.PLAIN, this.fontSize));
		// 取随机产生的认证码
		String code = "";
		for (int i = 0; i < length; i++) {
			String rand = "" + (dateBase[random.nextInt(dateBase.length)] );
			code += rand;
			// 将认证码显示到图象中
			g.setColor(new Color(20 + random.nextInt(110), 20 + random.nextInt(110), 20 + random.nextInt(110)));
			// 调用函数出来的颜色相同，可能是因为种子太接近，所以只能直接生成
			g.drawString(rand, (this.fontSize)*i, (this.imgHeight+this.fontSize)/2);
		}
		return code;
	}
	/**
	 *  给定范围获得随机颜色;
	 * @return
	 */
	private Color getRandColor() {
		Random random = new Random();
		int r = random.nextInt(255);
		int g = random.nextInt(255);
		int b = random.nextInt(255);
		return new Color(r, g, b);
	}
	/**
	 * 导出验证码图片到浏览器
	 * @param suffix	图片后缀
	 * @param response	
	 * @throws IOException
	 */
	public void exportForWeb(String suffix,HttpServletResponse response) throws IOException{
		// 图象生效 
		g.dispose();
		// 输出图象到页面 "JPEG"
		ImageIO.write(image, suffix, response.getOutputStream());
	}
	/**
	 * 导出验证码图片服务器本地
	 * @param fileName	文件名
	 * @param dir		目录
	 * @throws IOException
	 */
	public void exportForLocal(String fileName,String dir) throws IOException{
		OutputStream os = new FileOutputStream(dir+"/"+fileName);  
		// 输出图象到页面 "JPEG"
		ImageIO.write(image, "JPEG", os);
		os.close();
	}
	
}
