package verification;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sun.java2d.loops.DrawLine;

/**
 * @Project: 20160123_Verification
 * @Title: VerificationServlet
 * @Description:
 * @功能描述: 1.验证码大小可配置；2.文字数量，字体样式可配置；3.文字的内容可配置
 * @author: admin
 * @date: 2016年1月23日上午10:01:11
 * @company: webyun
 * @Copyright: Copyright (c) 2015
 * @version v1.0
 */
@WebServlet(value = "/verification")
public class VerificationServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("image/jpeg");//设置返回的格式
		resp.addHeader("pragma", "NO-cache");//参数页面不缓存
		resp.addHeader("Cache-Control", "no-cache");//图片不缓存
		resp.addDateHeader("Expries", 0);
		VerificationUtil util = new VerificationUtil(100,60);
		util.setFontType(ConfigDateBase.FONT_TYPES[4]);
		String code = util.code(ConfigDateBase.ALL, 4);
		HttpSession session = req.getSession();
		
		session.setAttribute("code1", code);
		session.setAttribute("code2", MD5.md5(code));
		
		System.out.println("验证码加密前:"+session.getAttribute("code1"));
		System.out.println("验证码加密后:"+session.getAttribute("code2"));
		
		util.exportForWeb("JPEG", resp);
	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	


		
}
