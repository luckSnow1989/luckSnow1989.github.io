package zx.account.web.controller;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * ��֤�����ɿ�����
 * @author zx
 */
@Controller
@RequestMapping("verification.do")
public class VerificationController {
	
	/**
	 * ��֤���������
	 * ʹ���첽���ؼ���
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */
	@RequestMapping(params="method=verification")
	@ResponseBody
	public void verification(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("image/jpeg");//���÷��صĸ�ʽ
		resp.addHeader("pragma", "NO-cache");//����ҳ�治����
		resp.addHeader("Cache-Control", "no-cache");//ͼƬ������
		resp.addDateHeader("Expries", 0);
		VerificationUtil util = new VerificationUtil(100,60);
		util.setFontType(ConfigDateBase.FONT_TYPES[4]);
		String code = util.code(ConfigDateBase.ALL, 4);
		HttpSession session = req.getSession();
		
		session.setAttribute("code1", code);
		session.setAttribute("code2", MD5.md5(code));
		
		System.out.println("��֤�����ǰ:"+session.getAttribute("code1"));
		System.out.println("��֤����ܺ�:"+session.getAttribute("code2"));
		
		util.exportForWeb("JPEG", resp);
	}
}
