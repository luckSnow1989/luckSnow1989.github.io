package com.zrgk.web.action;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.InterceptorRefs;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionSupport;


@Controller
@Action("ImgAction")
@Results({
	@Result(name = "success", location = "login.jsp"),
})
@ParentPackage("first")
@InterceptorRefs({
	@InterceptorRef("myInterceptor"),
	@InterceptorRef("defaultStack")
})
public class ImgAction extends ActionSupport {
	
	
	@Override
	public String execute() throws Exception {
		HttpServletResponse resp=ServletActionContext.getResponse();
		HttpServletRequest req=	ServletActionContext.getRequest();
		
		resp.setContentType("image/jpeg");//设置返回的格式
		resp.addHeader("pragma", "NO-cache");//参数页面不缓存
		resp.addHeader("Cache-Control", "no-cache");//图片不缓存
		resp.addDateHeader("Expries", 0);
		VerificationUtil util = new VerificationUtil(100,60);
		util.setFontType(ConfigDateBase.FONT_TYPES[4]);
		String code = util.code(ConfigDateBase.ALL, 4);
		HttpSession session = req.getSession();
		
		session.setAttribute("code1", code);
		session.setAttribute("code2", MD5.md5(code));
		
		System.out.println("验证码加密前:"+session.getAttribute("code1"));
		System.out.println("验证码加密后:"+session.getAttribute("code2"));
		
		util.exportForWeb("JPEG", resp);
		
		return SUCCESS;
	}
}
