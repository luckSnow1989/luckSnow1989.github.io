package servlet;

import java.io.IOException;

import javax.annotation.security.RunAs;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(
		//value = { "/user1", "/user2" },或 value = "/user",
		//value与urlPatterns只能配置一个,urlPatterns能指定一个URL,value可以指定多个
		//多使用value
		loadOnStartup = 2, //加载优先级，0和1已经被tomcat占用
		name = "UserServlet",//作为项目中的唯一标识
		urlPatterns="/user",
		initParams = {//需要初始化的参数
				@WebInitParam(name = "encoding", value = "UTF-8"),
				@WebInitParam(name = "path", value = "D://")
		},smallIcon="d://2.jpg",largeIcon="d://3.jpg",displayName="我的servlet"
)

//@MultipartConfig()//证明客户端提交的表单数据是由多部分组成的


public class UserServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	private ServletConfig config;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		boolean b = req.isUserInRole("boss");
		System.out.println(b);
		req.setAttribute("encoding", config.getInitParameter("encoding"));
		req.setAttribute("path", config.getInitParameter("path"));
		req.getRequestDispatcher("/index.jsp").forward(req, resp);
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		this.config = config;
	}
	
}
