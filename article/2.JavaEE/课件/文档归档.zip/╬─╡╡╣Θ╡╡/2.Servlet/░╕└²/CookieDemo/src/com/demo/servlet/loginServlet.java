package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * ��¼��Ϣ����
 * @author ��ѩ
 *
 */
public class loginServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		// ģ�⴦���������ȷ�ģ��Ϳ�ʼ���µĴ���
		
		// 1.����cookies
		Cookie newCookie =new Cookie("login_information", name+"0.0"+password);
		// 2.����cookies����Чʱ�䣨2*60�룩
		newCookie.setMaxAge(2*60);
		// 3.�����ɵ�cookies���صĿͻ���
		response.addCookie(newCookie);
		request.getRequestDispatcher("true.jsp").forward(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
