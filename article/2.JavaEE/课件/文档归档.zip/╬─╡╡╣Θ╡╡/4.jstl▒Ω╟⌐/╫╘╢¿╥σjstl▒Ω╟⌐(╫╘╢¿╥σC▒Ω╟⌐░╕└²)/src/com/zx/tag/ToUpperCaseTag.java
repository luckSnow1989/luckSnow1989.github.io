package com.zx.tag;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;
/**
  * @Title: ToUpperCaseTag
  * @Description: 转大写
  * @author: zhangxue
  * @date: 2016年6月14日下午9:11:47
  * @company: webyun
  * @Copyright: Copyright (c) 2015
  * @version v1.0
  */
public class ToUpperCaseTag extends SimpleTagSupport{
	@Override
	public void doTag() throws JspException, IOException {
		StringWriter sw = null;
		try {
			//1.缓存字符串输出流(作用：用于保存jsp页面上标签上的内容)
			sw = new StringWriter();
			//2.获得jsp内容对象(这个内容是指jstl标签内部的内容，例如<zhangxue:toUpper>demo</zhangxue:toUpper>，
			//demo就是这个内容的对象)
			JspFragment body = this.getJspBody();
			//3.将jsp页面上标签上的内容保存在缓存字符串输出流中
			body.invoke(sw);
			//4.获得jsp内容
			String content = sw.toString();
			//5.获得jspContext对象，对jsp进行输入/输出
			PageContext pc = (PageContext)this.getJspContext();
			//5.进行输出
			pc.getOut().write(content.toUpperCase());
			sw.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(sw != null)
				sw.close();
		}
	}
	
}
