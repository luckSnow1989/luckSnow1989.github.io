package com.zx.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
  * @Project: 20160612_jstl
  * @Title: IfTag
  * @Description: if判断标签
  * @author: zhangxue
  * @date: 2016年6月14日下午10:37:01
  * @company: webyun
  * @Copyright: Copyright (c) 2015
  * @version v1.0
  */
public class IfTag extends SimpleTagSupport{
	
	private boolean test;

	public void setTest(boolean test) {
		this.test = test;
	}
	
	@Override
	public void doTag() throws JspException, IOException {
		//PageContext pc = (PageContext)this.getJspContext();
		if(this.test){
			this.getJspBody().invoke(null);
		}
	}
}
