package com.zx.tag;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;
/**
  * @Project: 20160612_jstl
  * @Title: AppURLTag
  * @Description: 获得项目URL,如：http://127.0.0.1:8080/app
  * @author: zhangxue
  * @date: 2016年6月14日下午9:40:32
  * @company: webyun
  * @Copyright: Copyright (c) 2015
  * @version v1.0
  */
public class AppURLTag extends SimpleTagSupport{

	@Override
	public void doTag() throws JspException, IOException {
		PageContext jsp = (PageContext)this.getJspContext();
		HttpServletRequest request = (HttpServletRequest)jsp.getRequest();
		
		String path = request.getContextPath();
		System.out.println(path);
		
		jsp.getOut().write(path);
	}
	
}
