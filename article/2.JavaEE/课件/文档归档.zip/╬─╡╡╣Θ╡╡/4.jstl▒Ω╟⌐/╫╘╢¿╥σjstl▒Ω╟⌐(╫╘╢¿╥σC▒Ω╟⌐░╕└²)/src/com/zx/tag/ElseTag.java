package com.zx.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class ElseTag extends SimpleTagSupport{
	
	@Override
	public void doTag() throws JspException, IOException {
		//获得父类标签
		ChooseTag parent = (ChooseTag)getParent();
		//如果父标签标记为false，则执行自己标签的内容
		if(!parent.isFlag())
			getJspBody().invoke(null);
	}
}
