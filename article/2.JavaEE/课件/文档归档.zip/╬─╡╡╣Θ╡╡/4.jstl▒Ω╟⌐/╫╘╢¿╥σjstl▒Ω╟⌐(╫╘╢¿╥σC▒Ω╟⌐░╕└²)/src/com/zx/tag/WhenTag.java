package com.zx.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class WhenTag extends SimpleTagSupport{
	
	private boolean test;

	public void setTest(boolean test) {
		this.test = test;
	}

	@Override
	public void doTag() throws JspException, IOException {
		if(test){
			getJspBody().invoke(null);
			//获得父类标签
			ChooseTag parent = (ChooseTag)getParent();
			//改变父标签的标记
			parent.setFlag(true);
		}
	}
}
