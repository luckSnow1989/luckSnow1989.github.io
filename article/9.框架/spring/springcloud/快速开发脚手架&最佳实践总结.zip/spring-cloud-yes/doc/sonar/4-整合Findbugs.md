# 整合Findbugs

* 参考《插件安装一节》，安装Findbugs插件。

* 按照图示操作，导入项目的Findbugs规则

  ![](images/findbugs.png)

* 将该规则设为默认规则。

