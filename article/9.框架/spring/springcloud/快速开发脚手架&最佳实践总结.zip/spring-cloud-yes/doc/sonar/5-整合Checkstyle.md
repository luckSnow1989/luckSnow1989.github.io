# 整合Checkstyle

- 参考《插件安装一节》，安装Checkstyle插件。

- 按照图示操作，导入项目的Checkstyle规则

  ![](images/checkstyle.png)

- 将该规则设为默认规则。

