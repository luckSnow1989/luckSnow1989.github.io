# 整合PMD

方法同整合Findbugs、Checkstyle。