# 说明
本项目是包二使用的，整合了keycloak。
区别于edge-server，edge-server是提供给包一包三使用的zuul，不整合keycloak，只提供反向代理能力。
@孙念东


zuul整合keycloak的例子：https://github.com/lizhiguo/zuul-keycloak/blob/master/service-app/src/main/java/de/ctrlaltdel/sample/app/service/ServiceController.java