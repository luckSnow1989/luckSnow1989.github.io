jQuery.ulslide
=======

jQuery.ulslide plugin. Slider (or carousel) that supports "Slide", "Crossfade", "Fade",
HTML5 (CSS3) "3D Flip", "3D Cube", "Rotate", "Scale" and "Carousel" effects. Flexible, secure
for html layout (do not changes structure of HTML) and very simple to use.

The plugin supports Responsive design, images Preloading, Lazy Load and Ajax.
Any HTML can be used as slide content (not only images).

If the Mousewheel plugin has been included on the page then
the slider will also respond to the mouse wheel. (Set "mousewheel" option as "true")

Visit http://4coder.info/en/code/jquery-plugins/ulslide/ for more informations about this plugin.